import { init } from "./init.js";

window.addEventListener("load", init, false);
